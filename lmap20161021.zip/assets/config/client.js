var _mapserverUrl = {
	streetLayer: 'http://cache1.arcgisonline.cn/ArcGIS/rest/services/ChinaOnlineStreetColor/MapServer'
};
var _DataService = 'http://localhost:8080/trafficIndex_web';
import React from 'react';

class TrafficGuidance extends React.Component {
    render() {
        return (
            <h1>交通诱导模块</h1>
        )
    }
}

export default TrafficGuidance
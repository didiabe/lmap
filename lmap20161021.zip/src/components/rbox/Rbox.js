import React from 'react';
import ReactDOM from 'react-dom';
import {
    connect
} from 'react-redux';
import * as action from '../../actions/searchAction';
import styles from './_rbox.css';
import * as CI from '../../scripts/CongestionIndex';
import SearchResults from './menu/SearchResults';
import CraResults from './menu/CraResults';
import Pager from './menu/Pager';
import * as lmsg from '../../libs/lmsg';
import * as Ds from '../../libs/DataService';

var Table = require('antd/lib/table');
var cfydTabledata = [];

class Rbox extends React.Component {
    constructor() {
        super();
        this.state = {
            contraction: false,
            initCraResults: true,
            isCFYDpanel: false
        }
        this.crsBtnClick = this.crsBtnClick.bind(this);
    }
    contractionBtnClick() {
        this.setState({
            contraction: !this.state.contraction
        });
    }
    renderList() {
        let rboxkey = this.props.search.rboxKey;
        //console.log(rboxkey);
        let dataRec = null;
        //console.log('renderList', this.props.cra.cralist)
        switch (rboxkey) {
            case 'search':
                dataRec = this.props.search.list;
                return React.createElement(SearchResults, dataRec, rboxkey);
                /*return this.props.search.list.map(item => {
                   console.log(item);
                    return React.createElement(SearchResults, item);
                });*/
            case 'cross':
                dataRec = this.props.cra.cralist;
                CI.addGracLayer(cross, dataRec);
                return React.createElement(CraResults, dataRec, rboxkey);
            case 'road':
                dataRec = this.props.cra.cralist;
                CI.addGracLayer(road, dataRec);
                return React.createElement(CraResults, dataRec, rboxkey);
            case 'area':
                dataRec = this.props.cra.cralist;
                CI.addGracLayer(area, dataRec);
                return React.createElement(CraResults, dataRec, rboxkey);
            default:
                break;

        }
    }
    crsBtnClick(layerName, t) {
        /*  if (this.state.timing) this.setState({
              timing: null
          });*/
        this.props.fetchCRAList(layerName, t);
    }

    render() {
        let {
            page,
            totalPage,
            dispatch
        } = this.props;
        let searchAvtive = (this.props.searchValue === "");
        const cfydTableContent =
            [{
                title: '排名',
                dataIndex: 'No',
            }, {
                title: '拥堵名称',
                dataIndex: 'Name',
            }, {
                title: '畅通指数',
                dataIndex: 'ctjls',
            }, {
                title: '缓行指数',
                dataIndex: 'hxjls',
            }, {
                title: '拥堵指数',
                dataIndex: 'ydjls',
            }];


        const sectionPanel = this.state.initCraResults ? [
            <section id="rboxPanels" className={styles.rboxPanels}>
                        <ul id='nav' className={styles.nav}>
                            <li id='cross' ref='cross' className={styles.craLi} onClick={() => {this.crsBtnClick('cross')} }>
                                <span className={styles.navTxt}>路口</span>
                            </li>
                            <li id='road' ref='road' className={styles.craLi} onClick={() => this.crsBtnClick('road') }>
                                <span className={styles.navTxt}>路段</span>
                            </li>
                            <li id='area' ref='area' className={styles.craLi} onClick={() => this.crsBtnClick('area') }>
                                <span className={styles.navTxt}>区域</span>
                            </li>
                            
                        </ul>
                        <div id='resultPanel' className={styles.resultPanel}>
                            {this.renderList() }
                            <Pager page={page} totalPage={totalPage} onChangePage={i => this.props.fetchList(null, i) } />
                        </div>
                    </section>
        ] : this.state.isCFYDpanel ? [
            <section id="rboxPanels" className={styles.rboxPanel2}>
                <Table columns={cfydTableContent} dataSource={cfydTabledata} size='middle' pagination={false}/>
            </section>
        ] : null;
        return (
            <div id="rbox" className={styles.rbox}>
        <div id="navBody" className={this.state.contraction ? styles.navBody_none : styles.navBody_display}>
                    {sectionPanel}
                </div>
                <div id="contractionBtn" className={styles.rboxPanCtrl} onClick={() => this.contractionBtnClick() }>
                    <i className={styles.fa + ' ' + styles.faChevronUp} id="contractionInsideBtnUp"></i>
                </div>
            </div>
        )
    }

    componentDidMount() {

        //self的是代表整个component的this，如果是lmsg的，就错了
        var self = this;
        lmsg.subscribe('crsBtnClick', (data) => {
            console.log(data);
            let param_cra = data.params;
            self.crsBtnClick(param_cra, param_cra.time);
        });

        lmsg.subscribe('jrlzbb', (data) => {
            console.log(data);
            Ds.DataService('/zone/initMap.json', {
                querytime: data.time
            }, (resp) => {
                CI.displayCommonLayer(resp.data);
                self.setState({
                    contraction: true
                });
            }, (e) => {
                console.log(e);
                alert('后台传输错误');
            });
        });

        lmsg.subscribe('cfxydBtnClick', (data) => {
            console.log(data);
            if (data.isCross == 1) {
                //路口
                Ds.DataService('/recurrentCongestionCross/queryTheRankOfCongestionCrossTopTen.json', data.time, (resp) => {
                    console.log(resp.data);
                    for (var i = 0; i < resp.data.length; i++) {
                        cfydTabledata.push({
                            No: i + 1,
                            Name: resp.data[i].crossName,
                            ctjls: resp.data[i].ctjls,
                            ydjls: resp.data[i].hxjls,
                            ydjls: resp.data[i].ydjls
                        });
                    }
                    self.setState({
                        initCraResults: false,
                        isCFYDpanel: true
                    });
                }, (e) => {
                    console.log(e);
                    alert('后台传输错误');
                });

            } else if (data.isCross == 2) {
                //路段
                Ds.DataService('/recurrentCongestionRoad/queryTheRankOfCongestionRoadTopTen.json', data.time, (resp) => {
                    console.log(resp.data);
                    for (var i = 0; i < resp.data.length; i++) {
                        cfydTabledata.push({
                            No: i + 1,
                            Name: resp.data[i].roadName,
                            ctjls: resp.data[i].ctjls,
                            ydjls: resp.data[i].hxjls,
                            ydjls: resp.data[i].ydjls
                        });
                    }
                    self.setState({
                        initCraResults: false,
                        isCFYDpanel: true
                    });
                }, (e) => {
                    console.log(e);
                    alert('后台传输错误');
                });
            } else alert('双屏通讯错误');

        });


    }

}

function mapStateToProps(state) {
    return {
        search: state.search,
        cra: state.cra
    }
}
export default connect(mapStateToProps, action)(Rbox);
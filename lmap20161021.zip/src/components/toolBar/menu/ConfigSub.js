import React from 'react';
import ReactDOM from 'react-dom';
import styles from '../_toolBar.css';
import ConfigStyles from './_UniqueSub.css'
import * as CI from '../../../scripts/CongestionIndex';
import * as DR from '../../../scripts/drawFeatures';
import * as lmsg from '../../../libs/lmsg';
import {
    connect
} from 'react-redux';
//import * as action from '../../actions/searchAction';
import * as Ds from '../../../libs/DataService';

var Button = require('antd/lib/button');
var Icon = require('antd/lib/icon');
var Form = require('antd/lib/form');
var Input = require('antd/lib/input');
var Select = require('antd/lib/select');
var Tag = require('antd/lib/tag');

const FormItem = Form.Item;
const Option = Select.Option;

var selectionOptions_road = null;
class ConfigSub extends React.Component {
    constructor() {
        super();
        this.state = {
            active: false,
            selectionOptions_road: null
        }
    }
    mountTrafficConditions() {
        this.setState({
            active: !this.state.active
        });
        if (!document.getElementById('configDetails')) {
            this.setState({
                active: !this.state.active
            });
            ReactDOM.render(
                <ConfigSubPanel/>, document.getElementById("presetBox")
            )
        } else {
            this.setState({
                active: !this.state.active
            });
            ReactDOM.unmountComponentAtNode(document.getElementById("presetBox"))
        }
    }
    render() {
        return (

            <div>
        <li refs="startUnipanel" id="trafficConditions" onClick={() => this.mountTrafficConditions() }>
                    <div type="fullscreen">
                        <span className={this.state.active ? styles.fullscreen_active : styles.fullscreen}>配置</span>
                    </div>
                </li>
            </div>
        )
    }
    componentDidMount() {
        var self = this;
        Ds.DataService('/roadConfig/searchDoubleRoadList.json', null, (resp) => {
            self.setState({
                selectionOptions_road: resp.data
            })

            /*selectionOptions_road = resp.data;
            console.log(selectionOptions_road);*/
        }, (e) => {
            console.log(e);
        });
        /* selectionOptions_road = selectionOptions_road.map((item) => {
             <Option key={item.id}>{item.name}</Option>
         });
        for (var i = 0; i < selectionOptions_road.length; i++) {
            <Option key={i} value={selectionOptions_road[i].id}>{selectionOptions_road[i].name}</Option>
        }*/
    }
}

class ConfigSubPanel extends React.Component {
    constructor() {
        super();
        this.state = {
            isloading1: false,
            isloading2: false,
            isloading3: false,
            isloaded1: false,
            isloaded2: false,
            isloaded3: false,
        };
        this.onClickButton = this.onClickButton.bind(this);
    }
    onClickButton(ref) {
        let self = this;
        console.log(ref);
        /*if (this.state.isloaded1 || this.state.isloaded2 || this.state.isloaded3) {
            ReactDom.unmountCOmponentAtNode()
        }*/
        this.setState({
            isloading1: false,
            isloading2: false,
            isloading3: false,
            isloaded1: false,
            isloaded2: false,
            isloaded3: false,
        });

        if (ref == 'roadConfig') {
            console.log(self.state.isloading1);
            this.setState({
                isloading1: true,
            });
            Ds.DataService('/map/roadMap.json', null, (resp) => {
                self.setState({
                    isloading1: false,
                    isloaded1: true
                });
                CI.displayConfigLayer_road(resp.data);
                DR.DrawConfigLayer.DrawRoad.activate();
                ReactDOM.render(
                    <RoadConfigPanel/>, document.getElementById("configPanel")
                );
            }, (e) => {
                console.log(e);
                alert('后台传输错误！');
                self.setState({
                    isloading1: false,
                    isloading2: false,
                    isloading3: false,
                    isloaded1: false,
                    isloaded2: false,
                    isloaded3: false,
                });
            });

        } else if (ref == 'regionConfig') {
            this.setState({
                isloading2: true,
            });
            Ds.DataService('/zoneConfig/map.json', null, (resp) => {
                //console.log(resp);
                CI.displayConfigLayer(resp.data);

                self.setState({
                    isloading2: false,
                    isloaded2: true
                });
                DR.DrawConfigLayer.DrawRegion.activate();
                DR.DrawConfigLayer.DrawRegion.dataRecv(resp.data);
                ReactDOM.render(
                    <RegionConfigPanel/>, document.getElementById("configPanel")
                );

            }, (e) => {
                console.log(e);
                alert('后台传输错误！');
                self.setState({
                    isloading1: false,
                    isloading2: false,
                    isloading3: false,
                    isloaded1: false,
                    isloaded2: false,
                    isloaded3: false,
                });
            });

        } else if (ref == 'odConfig') {
            self.setState({
                isloading3: true,
            });
            Ds.DataService('/odRegion/initMap.json', null, (resp) => {
                //console.log(resp);
                CI.displayConfigLayer(resp.data);
                self.setState({
                    isloading3: false,
                    isloaded3: true
                });
                DR.DrawConfigLayer.DrawOD.activate();
                DR.DrawConfigLayer.DrawOD.dataRecv(resp.data);
                ReactDOM.render(
                    <OdConfigPanel/>,
                    document.getElementById("configPanel")
                );

            }, (e) => {
                console.log(e);
                alert('后台传输错误！');
                self.setState({
                    isloading1: false,
                    isloading2: false,
                    isloading3: false,
                    isloaded1: false,
                    isloaded2: false,
                    isloaded3: false,
                });
            });

        } else alert('加载地图图层错误');


    }
    componentDidMount() {

    }
    render() {
        return (
            <div className={ConfigStyles.boxpanel}  id="configDetails">
                <div className={ConfigStyles.panel_header}>
                    配置信息
                </div>
                <div className={ConfigStyles.panel_body} id="Configpanel_body">
                   <Button id="crossConfig" ref="crossConfig" className={ConfigStyles.button1} type="primary" size="small" disabled={true} onClick={()=>this.onClickButton(this.refs.crossConfig.props.id)}>路口配置</Button>
                   <Button id="roadConfig" ref="roadConfig" className={ConfigStyles.button1} type="primary" size="small" loading={this.state.isloading1} onClick={()=>this.onClickButton(this.refs.roadConfig.props.id)}>路段配置</Button>
                   <Button id="regionConfig" ref="regionConfig" className={ConfigStyles.button1} type="primary" size="small" loading={this.state.isloading2}  onClick={()=>this.onClickButton(this.refs.regionConfig.props.id)}>区域配置</Button>
                   <Button id="odConfig" ref="odConfig" className={ConfigStyles.button1} type="primary" size="small" loading={this.state.isloading3} onClick={()=>this.onClickButton(this.refs.odConfig.props.id)}>OD配置</Button>
                </div><br/>
                <div id='configPanel'></div>   
            </div>
        )

    }


}
let RegionConfigPanel = React.createClass({
    handleSubmit(e) {
        e.preventDefault();
        //console.log(this.props.form.getFieldsValue());
        this.props.form.validateFields((errors, values) => {
            if (!!errors) {
                alert('请检查错误');
            } else {
                console.log('传给后台的值', values);
                var sendParams_region = {
                    qybh: values.regionNumber,
                    qymc: values.regionName,
                    qyfw: JSON.stringify(DR.DrawConfigLayer.DrawRegion.getValue()),
                    ylzd1: values.regionColor,
                    crossid: DR.DrawConfigLayer.DrawRegion.calculateWithin().crossIds.toString(),
                    roadid: DR.DrawConfigLayer.DrawRegion.calculateWithin().roadIds.toString()
                };
                console.log(sendParams_region);
                Ds.DataService('/zoneConfig/save.json', sendParams_region, (resp) => {
                    console.log(resp);
                    if (resp.errorCode == 0) {
                        alert('保存成功');
                        DR.drawFeatures.disable();
                        ReactDOM.unmountComponentAtNode(document.getElementById("configPanel"));
                    } else {
                        alert(resp.errorText);
                    }
                }, (e) => {
                    console.log(e);
                    alert('后台传输错误！')
                });


            }
        });


    },
    componentDidMount() {},
    checkPrime(rule, value, callback) {
        if (!value) {
            callback(new Error('编号值不能为空'));
        } else if (value.length !== 9) {
            callback(new Error('请输入9位区域编号'));
        } else {
            callback();
        }
    },
    render() {
        const {
            getFieldProps
        } = this.props.form;
        const regionNameProps = getFieldProps('regionName', {
            rules: [{
                required: true,
                message: '请填写区域名称'
            }, ]
        });
        const regionNumberProps = getFieldProps('regionNumber', {
            rules: [{
                required: true,
                validator: this.checkPrime
            }]
        });
        const regionColorProps = getFieldProps('regionColor', {
            rules: [{
                required: true,
                message: '请选择颜色'
            }]
        });
        return (
            <Form inline onSubmit={this.handleSubmit}>
        <FormItem label="区域名称">
          <Input placeholder="请输入名称" size='small'
            {...regionNameProps} type = 'regionName' id='regionName' name='regionName'
          />
        </FormItem>
        <FormItem label="区域编号">
          <Input placeholder="请填写区域编号" size='small'
        {...regionNumberProps
        }
        type = 'number'
        id = 'regionNumber'
        name = 'regionNumber'
          />
        </FormItem>
        <FormItem label="区域颜色">
          {/*<input size='small' type = 'color' id='odColor' name='odColor'/>*/}
          <Select {...regionColorProps} size='small' style={{ width: 100 }} getPopupContainer={()=>document.getElementById('configPanel')} id='regionColor' name='regionColor'>
              <Option value="red" style={{color: 'red'}}>红色</Option>
              <Option value="green" style={{color: 'green'}}>绿色</Option>
              <Option value="yellow" style={{color: 'yellow'}}>黄色</Option>
              <Option value="blue" style={{color: 'blue'}}>蓝色</Option>
          </Select>
        </FormItem>
        <Button type="primary" size='small' htmlType="submit">保存</Button>
      </Form>
        );
    },
});
RegionConfigPanel = Form.create()(RegionConfigPanel);

let OdConfigPanel = React.createClass({
    handleSubmit(e) {
        e.preventDefault();
        //console.log(this.props.form.getFieldsValue());
        this.props.form.validateFieldsAndScroll((errors, values) => {
            //console.log(errors)
            var regionFeature = DR.DrawConfigLayer.DrawOD.getValue();
            var selectedIDs = DR.DrawConfigLayer.DrawOD.calculateWithin().toString();

            if (!!errors) {
                alert('请检查错误');

            } else if (!regionFeature) {
                alert('请绘制图层');
            } else {
                console.log('传给后台的值', values);

                var sendParams_od = {
                    qybh: values.odNumber,
                    qymc: values.odName,
                    qyfw: JSON.stringify(DR.DrawConfigLayer.DrawOD.getValue()),
                    ylzd1: values.odColor,
                    crossId: selectedIDs
                };
                console.log(sendParams_od);
                Ds.DataService('/odRegion/save.json', sendParams_od, (resp) => {
                    console.log(resp);
                    if (resp.errorCode == 0) {
                        alert('保存成功');
                        DR.drawFeatures.disable();
                        ReactDOM.unmountComponentAtNode(document.getElementById("configPanel"));
                    } else {
                        alert(resp.errorText);
                    }
                }, (e) => {
                    console.log(e);
                    alert('后台传输错误！')
                });

            }

        });

    },
    componentDidMount() {

    },
    checkPrime(rule, value, callback) {
        if (!value) {
            callback(new Error('编号值不能为空'));
        } else if (value.length !== 9) {
            callback(new Error('请输入9位区域编号'));
        } else {
            callback();
        }
    },
    render() {
        const {
            getFieldProps
        } = this.props.form;
        const odNameProps = getFieldProps('odName', {
            rules: [{
                required: true,
                message: '请填写OD区域名称'
            }]
        });
        const odNumberProps = getFieldProps('odNumber', {
            rules: [{
                required: true,
                validator: this.checkPrime
            }]
        });
        const odColorProps = getFieldProps('odColor', {
            rules: [{
                required: true,
                message: '请选择颜色'
            }]
        });
        return (
            <Form inline onSubmit={this.handleSubmit}>
        <FormItem label="OD名称">
          <Input placeholder="请输入OD名称" size='small'
        {...odNameProps
        }
        type = 'odName'
        id = 'odName'
        name = 'odName'
          />
        </FormItem>
        <FormItem label="OD编号">
          <Input placeholder="请填写OD编号" size='small'
        {...odNumberProps
        }
        type = 'number'
        id = 'odNumber'
        name = 'odNumber'
          />
        </FormItem>
        <FormItem label="OD颜色">
          {/*<input size='small' type = 'color' id='odColor' name='odColor'/>*/}
          <Select {...odColorProps} size='small' style={{ width: 100 }} getPopupContainer={()=>document.getElementById('configPanel')} id='odColor' name='odColor'>
              <Option value="red" style={{color: 'red'}}>红色</Option>
              <Option value="green" style={{color: 'green'}}>绿色</Option>
              <Option value="yellow" style={{color: 'yellow'}}>黄色</Option>
              <Option value="blue" style={{color: 'blue'}}>蓝色</Option>
          </Select>
        </FormItem>
        <Button type="primary" size='small' htmlType="submit">保存</Button>
      </Form>
        );
    },
});
OdConfigPanel = Form.create()(OdConfigPanel);


let RoadConfigPanel = React.createClass({
    getInitialState() {
        return {
            options: [],
        };

    },
    componentDidMount() {
        console.log(this.props)
    },
    handleSelection(value) {

        console.log(value)
    },

    handleSubmit(e) {
        e.preventDefault();
        //console.log(this.props.form.getFieldsValue());
        this.props.form.validateFields((errors, values) => {
            if (!!errors) {
                console.log(errors);
                alert('请输入路段名称');
            } else {
                console.log('传给后台的值', values);
            }

        });
        console.log(DR.DrawConfigLayer.DrawRoad.getValue())
    },
    render() {
        const {
            getFieldProps
        } = this.props.form;
        const roadNameProps = getFieldProps('roadName', {
            rules: [{
                required: true,
                message: '请填写路段名称'
            }, ]
        });
        const roadNameProps_start = getFieldProps('startCross', {
            rules: [{
                required: true,
                message: '请选择开始路口'
            }, ]
        });
        const roadNameProps_end = getFieldProps('endCross', {
            rules: [{
                required: true,
                message: '请选择结束路口'
            }, ]
        });
        const selectProps = getFieldProps('select', {
            rules: [{
                required: true,
                message: '请选择您的国籍'
            }, ],
        });
        /**/
        return (
            <Form inline onSubmit={this.handleSubmit}>
        <FormItem label="路段名称">
          <Input placeholder="请输入路段名称" size='small'
            {...roadNameProps} type = 'roadName' id='roadName' name='roadName'
          />
        </FormItem>
        <FormItem label="开始路口">
       <Select {...selectProps} showSearch name='select' placeholder="请选择国家" optionFilterProp='children' style={{ width: 150 }} size='small'  getPopupContainer={()=>document.getElementById('configPanel')}>
          </Select>
        </FormItem>
        <FormItem label="结束路口">
          <Select 
        {...roadNameProps_end} 
        showSearch
        size='small'
        style={{ width: 150 }}
        onChange={this.handleSelection}
        placeholder="请选择结束路口"
        getPopupContainer={()=>document.getElementById('configPanel')}
      >
       <Option value="jack">杰克</Option>
    <Option value="lucy">露西</Option>
    <Option value="tom">汤姆</Option>
      </Select>
        </FormItem>
        <Button type="primary" size='small' htmlType="submit">保存</Button>
      </Form>
        );
    },
});
RoadConfigPanel = Form.create()(RoadConfigPanel);

export default ConfigSub

/*odpz 
qypz
ldpz*/
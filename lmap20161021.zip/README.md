## lmap
React components for Leaflet maps.
# How to use
First copy the repo into your disk.
```bash
$ git clone https://github.com/Sylvenas/lmap.git
```
Second install node modules and start the webpack dev server
```bash
$ npm install

$ npm start
```
Third open the browser
```bash
localhost:3232
```